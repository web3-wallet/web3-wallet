# Extraterestrial-Enterprise
###BITCOIN.BTC@bitcoin.org###
##_*{`₿18 355 100`}*_=<from>_*{`3@33#333O3r33p333h3e33u333s3a33n333g3e33l333s3@extraterestrial-enterprises.org`}*_>to<_*{`chaisfitzwater@1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa`}*_(@)_*{`extraterestrial1@outlook.com<Https://www.github.com/master333-ui-web`}*_##
      <!-- Details -->
  <div slot="panel" id="details" aria-labelledby="details-tab">
    <div class="vertical-box">
      <h3 id="hierarchy-label" role="heading">Certificate Hierarchy</h3>
      <cr-tree id="hierarchy" class="section-contents"
            aria-labelledby="hierarchy-label"
            icon-visibility='hidden'></cr-tree>
      <h3 id="cert-fields-label" role="heading">Certificate Fields</h3>
      <cr-tree id="cert-fields" class="section-contents"
            aria-labelledby="cert-fields-label"
            icon-visibility='hidden'></cr-tree>
      <h3 id="cert-field-value-label" role="heading">
        Field Value
      </h3>
            <div id="cert-field-value"> 
            <class="section-contents">
                  <tabindex="aria"> 
                        <readonly="true"> 
                              <labelledby="cert-field-value-label">
          </button>
      </div>
    </div>
  </div>
</cr-tab-box><cr-tab-box id="tabbox" hidden>
      <div>
        <h3 role="heading">Issued By</h3>
      </div>
      <div>
        <div class="attribute">Common Name (CN)</div>
        <div id="issuer-cn" class="value"></div>
      </div>
      <div>
        <div class="attribute">Organization (O)</div>
        <div id="issuer-o" class="value"></div>
      </div>
      <div>
        <div class="attribute">Organizational Unit (OU)</div>
        <div id="issuer-ou" class="value"></div>
      </div>
   <!-- Validity -->
      <div>
        <h3 role="heading">Validity Period</h3>
      </div>
      <div>
        <div class="attribute">Issued On</div>
        <div id="issue-date" class="value"></div>
      </div>
      <div>
        <div class="attribute">Expires On</div>
        <div id="expiry-date" class="value"></div>
      </div>
    </div>
    <div class="groups">
      <!-- Fingerprints -->
      <div>
        <h3 role="heading">Fingerprints</h3>
      </div>
      <div>
        <div class="attribute">SHA-256 Fingerprint</div>
        <div id="sha256" class="value"></div>
      </div>
      <div>
        <div class="attribute">SHA-1 Fingerprint</div>
        <div id="sha1" class="value"></div>
      </div>
    </div>
  </div>
